use std::f32::consts::PI;

use bevy::prelude::*;

use super::{Astronaut, AstronautStatus, GridPosition};
use crate::world::{PlanetProfile, footprint_center};

const VITESSE_LISSAGE_MARCHE: f32 = 3.10;
const VITESSE_LISSAGE_RETOUR: f32 = 3.55;
const VITESSE_LISSAGE_IDLE: f32 = 0.0;
const LISSAGE_ORIENTATION_OUVRIER: f32 = 9.0;

#[derive(Component, Clone, Copy, Debug, Default, PartialEq)]
pub struct PositionMondeLisse(pub Vec2);

#[derive(Component, Clone, Copy, Debug, Default, PartialEq)]
pub struct CibleMondeLisse(pub Vec2);

#[derive(Component, Clone, Copy, Debug, Default)]
pub struct AnimationOuvrier {
    pub phase_pas: f32,
    pub orientation: f32,
    pub vitesse_normalisee: f32,
    pub intensite_travail: f32,
}

pub fn initialiser_ouvriers_lisses(
    mut commands: Commands,
    profile: Res<PlanetProfile>,
    query: Query<(Entity, &GridPosition), (Added<Astronaut>, Without<PositionMondeLisse>)>,
) {
    for (entity, position) in &query {
        let monde = footprint_center(&[position.0], profile.cell_size_meters);
        commands.entity(entity).insert((
            PositionMondeLisse(monde),
            CibleMondeLisse(monde),
            AnimationOuvrier::default(),
        ));
    }
}

pub fn mettre_a_jour_cibles_ouvriers(
    profile: Res<PlanetProfile>,
    mut query: Query<(&GridPosition, Ref<GridPosition>, &mut CibleMondeLisse), With<Astronaut>>,
) {
    for (position, position_ref, mut cible) in &mut query {
        if !position_ref.is_changed() {
            continue;
        }

        cible.0 = footprint_center(&[position.0], profile.cell_size_meters);
    }
}

pub fn interpoler_ouvriers(
    time: Res<Time>,
    mut query: Query<(
        &Astronaut,
        &mut PositionMondeLisse,
        &CibleMondeLisse,
        &mut AnimationOuvrier,
    )>,
) {
    let delta = time.delta_secs();
    if delta <= 0.0 {
        return;
    }

    for (astronaut, mut position, cible, mut animation) in &mut query {
        if astronaut.status == AstronautStatus::Dead {
            animation.vitesse_normalisee = 0.0;
            animation.intensite_travail = 0.0;
            animation.phase_pas += delta * 0.4;
            continue;
        }

        let vitesse_max = match astronaut.status {
            AstronautStatus::Idle => VITESSE_LISSAGE_IDLE,
            AstronautStatus::Moving => VITESSE_LISSAGE_MARCHE,
            AstronautStatus::Working => VITESSE_LISSAGE_IDLE,
            AstronautStatus::Returning => VITESSE_LISSAGE_RETOUR,
            AstronautStatus::Dead => 0.0,
        };

        let delta_cible = cible.0 - position.0;
        let distance = delta_cible.length();
        if vitesse_max <= 0.0 || distance <= 0.0001 {
            position.0 = cible.0;
            animation.vitesse_normalisee = 0.0;
            animation.intensite_travail = if astronaut.status == AstronautStatus::Working {
                1.0
            } else {
                0.0
            };
            animation.phase_pas += delta * if animation.intensite_travail > 0.0 { 4.3 } else { 1.2 };
            continue;
        }

        let direction = delta_cible.normalize();
        let pas = vitesse_max * delta;
        let mouvement = direction * pas.min(distance);
        position.0 += mouvement;

        let orientation_cible = direction.x.atan2(direction.y);
        animation.orientation = lerp_angle(
            animation.orientation,
            orientation_cible,
            (delta * LISSAGE_ORIENTATION_OUVRIER).clamp(0.0, 1.0),
        );
        animation.vitesse_normalisee =
            (mouvement.length() / (vitesse_max * delta.max(0.001))).clamp(0.0, 1.0);
        animation.intensite_travail = if astronaut.status == AstronautStatus::Working {
            1.0
        } else {
            0.0
        };
        animation.phase_pas += delta * (3.0 + 5.4 * animation.vitesse_normalisee);
    }
}

fn lerp_angle(from: f32, to: f32, factor: f32) -> f32 {
    let mut delta = (to - from) % (PI * 2.0);
    if delta > PI {
        delta -= PI * 2.0;
    } else if delta < -PI {
        delta += PI * 2.0;
    }
    from + delta * factor
}
