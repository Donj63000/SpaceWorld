use bevy::prelude::*;

use super::{
    AnimationOuvrier, AnimationPromenade, ApparenceAstronaute, Astronaut, AstronautStatus,
    AstronautePromeneur, EtatPromenade, RigAstronaute,
};
use super::rendu_realiste::{
    offset_bras_droit, offset_bras_gauche, offset_jambe_droite, offset_jambe_gauche,
    offset_tete, offset_torse,
};

pub fn animer_rig_ouvriers(
    time: Res<Time>,
    mut transforms: Query<&mut Transform>,
    query: Query<(&Astronaut, &ApparenceAstronaute, &AnimationOuvrier, &RigAstronaute)>,
) {
    let temps = time.elapsed_secs();
    for (astronaut, apparence, animation, rig) in &query {
        appliquer_pose_rig(
            temps,
            rig,
            apparence,
            animation.phase_pas,
            animation.vitesse_normalisee,
            animation.intensite_travail,
            false,
            astronaut.status == AstronautStatus::Dead,
            &mut transforms,
        );
    }
}

pub fn animer_rig_promeneurs(
    time: Res<Time>,
    mut transforms: Query<&mut Transform>,
    query: Query<(&AstronautePromeneur, &ApparenceAstronaute, &AnimationPromenade, &RigAstronaute)>,
) {
    let temps = time.elapsed_secs();
    for (promeneur, apparence, animation, rig) in &query {
        appliquer_pose_rig(
            temps,
            rig,
            apparence,
            animation.phase_pas,
            animation.vitesse_normalisee,
            0.0,
            promeneur.etat == EtatPromenade::Pause,
            false,
            &mut transforms,
        );
    }
}

fn appliquer_pose_rig(
    temps: f32,
    rig: &RigAstronaute,
    apparence: &ApparenceAstronaute,
    phase_pas: f32,
    vitesse_normalisee: f32,
    intensite_travail: f32,
    est_en_pause: bool,
    est_mort: bool,
    transforms: &mut Query<&mut Transform>,
) {
    if est_mort {
        ecrire_transform(
            transforms,
            rig.torse,
            offset_torse() + Vec3::new(0.0, -0.16, 0.0),
            Quat::from_rotation_x(0.24),
        );
        ecrire_transform(
            transforms,
            rig.tete,
            offset_tete() + Vec3::new(0.0, -0.12, -0.04),
            Quat::from_rotation_x(-0.30),
        );
        ecrire_transform(
            transforms,
            rig.bras_gauche,
            offset_bras_gauche(),
            Quat::from_rotation_z(-0.18) * Quat::from_rotation_x(-1.04),
        );
        ecrire_transform(
            transforms,
            rig.bras_droit,
            offset_bras_droit(),
            Quat::from_rotation_z(0.18) * Quat::from_rotation_x(-0.82),
        );
        ecrire_transform(
            transforms,
            rig.jambe_gauche,
            offset_jambe_gauche(),
            Quat::from_rotation_x(0.20),
        );
        ecrire_transform(
            transforms,
            rig.jambe_droite,
            offset_jambe_droite(),
            Quat::from_rotation_x(-0.08),
        );
        return;
    }

    let amplitude_combinaison = apparence.combinaison.amplitude_pas();
    let balancement = phase_pas.sin() * 0.72 * vitesse_normalisee * amplitude_combinaison;
    let rebond = (phase_pas * 2.0).sin().abs() * 0.06 * vitesse_normalisee;
    let respiration = (temps * 2.1).sin() * 0.018;
    let regard = if est_en_pause {
        (temps * 1.6).sin() * 0.18
    } else {
        0.0
    };
    let oscillation_travail = (temps * 6.2).sin() * 0.22 * intensite_travail;
    let inclinaison = 0.12 * vitesse_normalisee + 0.18 * intensite_travail;

    ecrire_transform(
        transforms,
        rig.torse,
        offset_torse() + Vec3::new(0.0, rebond + respiration * 0.35, 0.0),
        Quat::from_rotation_x(-inclinaison + respiration * 0.08),
    );
    ecrire_transform(
        transforms,
        rig.tete,
        offset_tete() + Vec3::new(0.0, rebond * 0.40, 0.0),
        Quat::from_rotation_y(regard) * Quat::from_rotation_x(respiration * 0.12),
    );
    ecrire_transform(
        transforms,
        rig.bras_gauche,
        offset_bras_gauche() + Vec3::new(0.0, rebond * 0.12, 0.0),
        Quat::from_rotation_x(-balancement - oscillation_travail - intensite_travail * 0.10),
    );
    ecrire_transform(
        transforms,
        rig.bras_droit,
        offset_bras_droit() + Vec3::new(0.0, rebond * 0.12, 0.0),
        Quat::from_rotation_x(balancement + oscillation_travail - intensite_travail * 0.26),
    );
    ecrire_transform(
        transforms,
        rig.jambe_gauche,
        offset_jambe_gauche() + Vec3::new(0.0, rebond * 0.08, 0.0),
        Quat::from_rotation_x(balancement * 0.84),
    );
    ecrire_transform(
        transforms,
        rig.jambe_droite,
        offset_jambe_droite() + Vec3::new(0.0, rebond * 0.08, 0.0),
        Quat::from_rotation_x(-balancement * 0.84),
    );
}

fn ecrire_transform(
    transforms: &mut Query<&mut Transform>,
    entity: Entity,
    translation: Vec3,
    rotation: Quat,
) {
    if let Ok(mut transform) = transforms.get_mut(entity) {
        transform.translation = translation;
        transform.rotation = rotation;
    }
}
