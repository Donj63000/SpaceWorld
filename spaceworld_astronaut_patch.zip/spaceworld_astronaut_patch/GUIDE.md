# Refonte astronautes réalistes - SpaceWorld

## 1. Ce que tu changes tout de suite

Dans l'état actuel du projet, les astronautes sont surtout gérés ici :

- `src/colony/mod.rs`
  - bootstrap de la colonie
  - enregistrement des systèmes colony
- `src/colony/astronautes/mod.rs`
  - logique astronautes
  - visuels actuels en primitives
  - animation actuelle du `promeneur`

Le problème du projet actuel n'est pas la simulation métier. Elle est globalement exploitable.
Le problème, c'est la couche **représentation / apparence / animation** :

- ouvriers non animés correctement,
- un seul vrai rig visuel (le promeneur),
- aucune vraie notion de type de combinaison,
- pas de différenciation visuelle propre entre les astronautes,
- pas de couche de rendu réutilisable,
- pas de mouvement lissé pour les ouvriers.

La bonne stratégie n'est donc **pas** de réécrire toute la simulation.
La bonne stratégie est :

1. garder la simulation existante,
2. ajouter une couche `apparence + rig + animation + mouvement lisse`,
3. brancher cette couche sur les astronautes actuels,
4. préparer ensuite le passage vers de vrais meshes GLTF plus tard.

---

## 2. Architecture cible

Ajoute 4 nouveaux fichiers dans `src/colony/astronautes/` :

- `apparence.rs`
- `mouvement_lisse.rs`
- `rendu_realiste.rs`
- `animation_realiste.rs`

Le rôle de chaque fichier :

- `apparence.rs`
  - définit les rôles d'astronautes
  - définit les types de combinaisons
  - injecte une apparence par défaut sur chaque astronaute

- `mouvement_lisse.rs`
  - crée une position monde lissée pour les ouvriers à partir de la grille
  - crée une vraie animation de déplacement exploitable côté rendu

- `rendu_realiste.rs`
  - construit un rig modulaire plus crédible
  - remplace les silhouettes bloc trop simples
  - synchronise le rendu root avec la position monde

- `animation_realiste.rs`
  - anime tous les rigs
  - applique marche / respiration / posture de travail / posture de mort

---

## 3. Modification à faire dans `src/colony/astronautes/mod.rs`

Au tout début du fichier, ajoute ces lignes juste après les `use` standard ou juste avant les définitions métiers, en gardant l'ordre suivant :

```rust
mod apparence;
mod animation_realiste;
mod mouvement_lisse;
mod rendu_realiste;

pub use apparence::{
    ApparenceAstronaute,
    RoleAstronaute,
    TypeCombinaison,
    initialiser_apparences_astronautes,
};
pub use animation_realiste::{animer_rig_ouvriers, animer_rig_promeneurs};
pub use mouvement_lisse::{
    AnimationOuvrier,
    CibleMondeLisse,
    PositionMondeLisse,
    initialiser_ouvriers_lisses,
    interpoler_ouvriers,
    mettre_a_jour_cibles_ouvriers,
};
pub use rendu_realiste::{
    RigAstronaute,
    greffer_rig_ouvriers,
    greffer_rig_promeneurs,
    synchroniser_rendu_ouvriers_lisse,
    synchroniser_rendu_promeneurs_realistes,
};
```

Ne supprime pas encore l'ancien contenu du fichier.
Le but immédiat est de **superposer proprement** la nouvelle couche sans casser la logique métier existante.

---

## 4. Fichiers à créer

Crée exactement les fichiers suivants avec le contenu fourni :

- `src/colony/astronautes/apparence.rs`
- `src/colony/astronautes/mouvement_lisse.rs`
- `src/colony/astronautes/rendu_realiste.rs`
- `src/colony/astronautes/animation_realiste.rs`

Tu les trouveras dans ce patch.

---

## 5. Modification à faire dans `src/colony/mod.rs`

### 5.1 Remplace le bloc de systèmes visuels colony

Dans `impl Plugin for ColonyPlugin`, remplace ce bloc :

```rust
.add_systems(
    Update,
    (
        ensure_structure_visuals,
        astronautes::ensure_astronaut_visuals,
        astronautes::ensure_promeneur_visuals,
        ensure_loose_ice_visuals,
        sync_structure_visuals,
        astronautes::sync_astronaut_visuals,
        astronautes::sync_promeneur_visuals,
        sync_loose_ice_visuals,
    ),
)
.add_systems(
    Update,
    astronautes::deplacer_promeneur.run_if(in_state(GameState::InGame)),
)
.add_systems(
    Update,
    astronautes::animer_promeneur.run_if(in_state(GameState::InGame)),
)
```

par ceci :

```rust
.add_systems(
    Update,
    (
        ensure_structure_visuals,
        ensure_loose_ice_visuals,
        sync_structure_visuals,
        sync_loose_ice_visuals,
    ),
)
.add_systems(
    Update,
    (
        astronautes::initialiser_apparences_astronautes,
        astronautes::initialiser_ouvriers_lisses,
        astronautes::greffer_rig_ouvriers,
        astronautes::greffer_rig_promeneurs,
    )
        .chain(),
)
.add_systems(
    Update,
    (
        astronautes::mettre_a_jour_cibles_ouvriers,
        astronautes::interpoler_ouvriers,
        astronautes::deplacer_promeneur,
        astronautes::synchroniser_rendu_ouvriers_lisse,
        astronautes::synchroniser_rendu_promeneurs_realistes,
        astronautes::animer_rig_ouvriers,
        astronautes::animer_rig_promeneurs,
    )
        .chain()
        .run_if(in_state(GameState::InGame)),
)
```

### 5.2 Pourquoi ce remplacement est le bon

Ce remplacement fait 3 choses essentielles :

- il garde les bâtiments et la glace au même endroit,
- il remplace la couche visuelle astronautes par une nouvelle pipeline propre,
- il force un ordre stable :
  - cible de mouvement,
  - interpolation,
  - déplacement promeneur,
  - sync rendu,
  - animation.

C'est exactement ce qu'il faut pour éviter des personnages qui glissent, popent ou animent avec un frame de retard.

---

## 6. Option très recommandée dans `src/app.rs`

Si tu veux préparer le passage futur vers de vrais assets Blender / GLTF animés, remplace :

```rust
        .build()
        .disable::<bevy::audio::AudioPlugin>()
        .disable::<bevy::gltf::GltfPlugin>()
        .disable::<bevy::gilrs::GilrsPlugin>()
        .disable::<bevy::animation::AnimationPlugin>();
```

par :

```rust
        .build()
        .disable::<bevy::audio::AudioPlugin>()
        .disable::<bevy::gilrs::GilrsPlugin>();
```

Fais-le maintenant même si tu gardes encore les personnages procéduraux.
Sinon tu bloques inutilement la future intégration de vrais modèles.

---

## 7. Direction artistique concrète à viser dans les modèles

Pour être crédible dans SpaceWorld, ne fais pas un astronaute générique cartoon.
Fais une lecture claire en top-down / semi top-down :

### Extérieur Mars / surface

- combinaison EVA blanche / gris clair,
- joints souples gris,
- anneaux rigides visibles aux épaules / coudes / hanches / genoux,
- backpack vie bien lisible,
- visière dorée,
- chest box lisible,
- bottes plus volumineuses,
- bande couleur par rôle.

### Intérieur habitat / véhicule (plus tard)

- silhouette plus fine,
- pas de backpack externe,
- casque plus discret ou non visible,
- tissus plus souples,
- moins d'amplitude visuelle dans les joints,
- palette plus sobre.

### Rôles

- commandant : bande rouge
- ingénieur : bande orange
- scientifique : bande bleue
- logisticien : bande ambre / jaune chaud
- civil / visiteur : bande grise

---

## 8. Ce que ce patch améliore immédiatement

Avec ce patch, tu obtiens tout de suite :

- des ouvriers animés,
- des promeneurs animés avec le même langage visuel,
- une silhouette EVA plus crédible,
- une base de code nettement plus propre,
- une couche apparence séparée de la logique métier,
- une passerelle simple vers des vrais meshes plus tard.

---

## 9. Ce qu'il faudra faire ensuite pour passer au niveau production final

Une fois ce patch intégré, la suite propre est :

1. faire 2 meshes Blender :
   - `astronaute_eva_lourd`
   - `astronaute_eva_leger`
2. garder exactement les mêmes rôles et mêmes types de combinaison,
3. conserver la même API ECS,
4. remplacer le rig procédural par un loader GLTF,
5. garder `ApparenceAstronaute`, `AnimationOuvrier` et `AnimationPromenade` comme couche de pilotage.

C'est important :
la bonne architecture n'est pas de faire dépendre la simulation du mesh.
C'est le mesh qui doit dépendre de la simulation.

---

## 10. Résultat attendu visuellement

Après intégration correcte, tu dois voir :

- Ari, Noor et Sora avec une vraie silhouette d'astronaute EVA plus lourde,
- Mila avec une silhouette EVA plus légère,
- des respirations idle,
- une marche lisible avec inertie,
- une posture de travail distincte,
- une posture de mort claire,
- des couleurs de rôle lisibles même en caméra éloignée.

