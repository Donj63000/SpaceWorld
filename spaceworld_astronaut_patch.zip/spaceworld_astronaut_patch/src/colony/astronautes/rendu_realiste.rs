use bevy::prelude::*;

use super::{
    AnimationOuvrier, AnimationPromenade, ApparenceAstronaute, Astronaut, AstronautStatus,
    AstronautePromeneur, PositionMonde, PositionMondeLisse, RoleAstronaute, TypeCombinaison,
};
use super::super::ColonyVisualAssets;
use crate::core::WorldOrigin;
use crate::world::{
    PlanetProfile, WorldCache, WorldSeed, continuous_world_to_render_translation,
};

#[derive(Component, Clone, Copy, Debug)]
pub struct RigAstronaute {
    pub torse: Entity,
    pub tete: Entity,
    pub bras_gauche: Entity,
    pub bras_droit: Entity,
    pub jambe_gauche: Entity,
    pub jambe_droite: Entity,
}

pub(crate) fn offset_torse() -> Vec3 {
    Vec3::new(0.0, 0.98, -0.02)
}

pub(crate) fn offset_tete() -> Vec3 {
    Vec3::new(0.0, 1.64, 0.04)
}

pub(crate) fn offset_bras_gauche() -> Vec3 {
    Vec3::new(-0.38, 1.30, 0.0)
}

pub(crate) fn offset_bras_droit() -> Vec3 {
    Vec3::new(0.38, 1.30, 0.0)
}

pub(crate) fn offset_jambe_gauche() -> Vec3 {
    Vec3::new(-0.16, 0.80, 0.0)
}

pub(crate) fn offset_jambe_droite() -> Vec3 {
    Vec3::new(0.16, 0.80, 0.0)
}

pub fn greffer_rig_ouvriers(
    mut commands: Commands,
    visuals: Res<ColonyVisualAssets>,
    query: Query<(Entity, &ApparenceAstronaute), (Added<Astronaut>, Without<RigAstronaute>)>,
) {
    for (entity, apparence) in &query {
        commands.entity(entity).insert((
            Transform::default(),
            GlobalTransform::default(),
            Visibility::default(),
        ));
        let rig = attacher_rig_astronaute(entity, &mut commands, &visuals, apparence);
        commands.entity(entity).insert(rig);
    }
}

pub fn greffer_rig_promeneurs(
    mut commands: Commands,
    visuals: Res<ColonyVisualAssets>,
    query: Query<
        (Entity, &ApparenceAstronaute),
        (Added<AstronautePromeneur>, Without<RigAstronaute>),
    >,
) {
    for (entity, apparence) in &query {
        commands.entity(entity).insert((
            Transform::default(),
            GlobalTransform::default(),
            Visibility::default(),
        ));
        let rig = attacher_rig_astronaute(entity, &mut commands, &visuals, apparence);
        commands.entity(entity).insert(rig);
    }
}

pub fn synchroniser_rendu_ouvriers_lisse(
    mut cache: ResMut<WorldCache>,
    profile: Res<PlanetProfile>,
    seed: Res<WorldSeed>,
    origin: Res<WorldOrigin>,
    mut query: Query<(
        &Astronaut,
        &ApparenceAstronaute,
        &PositionMondeLisse,
        &AnimationOuvrier,
        &mut Transform,
    )>,
) {
    for (astronaut, apparence, position, animation, mut transform) in &mut query {
        transform.translation = continuous_world_to_render_translation(
            position.0, 0.06, &mut cache, &profile, *seed, &origin,
        );
        if astronaut.status == AstronautStatus::Dead {
            transform.translation.y -= 0.26;
            transform.rotation =
                Quat::from_rotation_y(animation.orientation) * Quat::from_rotation_z(-0.92);
        } else {
            transform.rotation = Quat::from_rotation_y(animation.orientation);
        }
        transform.scale = Vec3::splat(apparence.echelle);
    }
}

pub fn synchroniser_rendu_promeneurs_realistes(
    mut cache: ResMut<WorldCache>,
    profile: Res<PlanetProfile>,
    seed: Res<WorldSeed>,
    origin: Res<WorldOrigin>,
    mut query: Query<(
        &ApparenceAstronaute,
        &PositionMonde,
        &AnimationPromenade,
        &mut Transform,
    ), With<AstronautePromeneur>>,
) {
    for (apparence, position, animation, mut transform) in &mut query {
        transform.translation = continuous_world_to_render_translation(
            position.0, 0.06, &mut cache, &profile, *seed, &origin,
        );
        transform.rotation = Quat::from_rotation_y(animation.orientation);
        transform.scale = Vec3::splat(apparence.echelle);
    }
}

fn attacher_rig_astronaute(
    entity: Entity,
    commands: &mut Commands,
    visuals: &ColonyVisualAssets,
    apparence: &ApparenceAstronaute,
) -> RigAstronaute {
    let mut torse = None;
    let mut tete = None;
    let mut bras_gauche = None;
    let mut bras_droit = None;
    let mut jambe_gauche = None;
    let mut jambe_droite = None;

    let materiau_role = materiau_role(visuals, apparence.role);
    let combinaison_eva = apparence.combinaison.est_eva();
    let casque_integral = apparence.combinaison.casque_integral();
    let sac_dorsal = apparence.combinaison.sac_dorsal();

    commands.entity(entity).with_children(|parent| {
        let mut piece = |parent,
                         mesh: Handle<Mesh>,
                         material: Handle<StandardMaterial>,
                         translation: Vec3,
                         scale: Vec3| {
            parent.spawn((
                Mesh3d(mesh),
                MeshMaterial3d(material),
                Transform::from_translation(translation).with_scale(scale),
            ));
        };

        torse = Some(
            parent
                .spawn((
                    Transform::from_translation(offset_torse()),
                    GlobalTransform::default(),
                    Visibility::default(),
                ))
                .with_children(|pivot| {
                    let torse_eva = if combinaison_eva {
                        Vec3::new(0.60, 0.84, 0.44)
                    } else {
                        Vec3::new(0.54, 0.76, 0.38)
                    };

                    piece(
                        pivot,
                        visuals.cube_mesh.clone(),
                        visuals.suit_material.clone(),
                        Vec3::ZERO,
                        torse_eva,
                    );
                    piece(
                        pivot,
                        visuals.cube_mesh.clone(),
                        visuals.hull_secondary_material.clone(),
                        Vec3::new(0.0, -0.44, 0.0),
                        Vec3::new(0.44, 0.18, 0.34),
                    );
                    piece(
                        pivot,
                        visuals.sphere_mesh.clone(),
                        visuals.hull_secondary_material.clone(),
                        Vec3::new(-0.34, 0.20, 0.0),
                        Vec3::new(0.12, 0.12, 0.12),
                    );
                    piece(
                        pivot,
                        visuals.sphere_mesh.clone(),
                        visuals.hull_secondary_material.clone(),
                        Vec3::new(0.34, 0.20, 0.0),
                        Vec3::new(0.12, 0.12, 0.12),
                    );
                    piece(
                        pivot,
                        visuals.cube_mesh.clone(),
                        visuals.frame_material.clone(),
                        Vec3::new(0.0, 0.08, 0.26),
                        Vec3::new(0.18, 0.20, 0.10),
                    );
                    piece(
                        pivot,
                        visuals.cube_mesh.clone(),
                        visuals.hull_secondary_material.clone(),
                        Vec3::new(0.0, -0.16, 0.22),
                        Vec3::new(0.12, 0.10, 0.08),
                    );
                    piece(
                        pivot,
                        visuals.cube_mesh.clone(),
                        materiau_role.clone(),
                        Vec3::new(-0.24, 0.12, 0.23),
                        Vec3::new(0.18, 0.05, 0.02),
                    );

                    if sac_dorsal {
                        piece(
                            pivot,
                            visuals.cube_mesh.clone(),
                            visuals.frame_material.clone(),
                            Vec3::new(0.0, 0.06, -0.34),
                            Vec3::new(0.44, 0.70, 0.24),
                        );
                        piece(
                            pivot,
                            visuals.cube_mesh.clone(),
                            visuals.hull_secondary_material.clone(),
                            Vec3::new(0.0, 0.28, -0.52),
                            Vec3::new(0.34, 0.16, 0.06),
                        );
                        piece(
                            pivot,
                            visuals.cube_mesh.clone(),
                            visuals.hull_secondary_material.clone(),
                            Vec3::new(-0.18, -0.04, -0.44),
                            Vec3::new(0.10, 0.42, 0.10),
                        );
                        piece(
                            pivot,
                            visuals.cube_mesh.clone(),
                            visuals.hull_secondary_material.clone(),
                            Vec3::new(0.18, -0.04, -0.44),
                            Vec3::new(0.10, 0.42, 0.10),
                        );
                        piece(
                            pivot,
                            visuals.cube_mesh.clone(),
                            visuals.lit_material.clone(),
                            Vec3::new(0.0, 0.20, -0.58),
                            Vec3::new(0.08, 0.08, 0.03),
                        );
                    }
                })
                .id(),
        );

        tete = Some(
            parent
                .spawn((
                    Transform::from_translation(offset_tete()),
                    GlobalTransform::default(),
                    Visibility::default(),
                ))
                .with_children(|pivot| {
                    piece(
                        pivot,
                        visuals.sphere_mesh.clone(),
                        visuals.suit_material.clone(),
                        Vec3::ZERO,
                        if casque_integral {
                            Vec3::new(0.44, 0.44, 0.44)
                        } else {
                            Vec3::new(0.32, 0.36, 0.32)
                        },
                    );

                    if casque_integral {
                        piece(
                            pivot,
                            visuals.sphere_mesh.clone(),
                            visuals.visor_material.clone(),
                            Vec3::new(0.0, 0.02, 0.18),
                            Vec3::new(0.28, 0.22, 0.18),
                        );
                        piece(
                            pivot,
                            visuals.cube_mesh.clone(),
                            visuals.frame_material.clone(),
                            Vec3::new(0.0, -0.26, 0.0),
                            Vec3::new(0.28, 0.08, 0.28),
                        );
                        piece(
                            pivot,
                            visuals.cube_mesh.clone(),
                            visuals.lit_material.clone(),
                            Vec3::new(-0.15, 0.13, -0.16),
                            Vec3::new(0.06, 0.06, 0.12),
                        );
                        piece(
                            pivot,
                            visuals.cube_mesh.clone(),
                            visuals.lit_material.clone(),
                            Vec3::new(0.15, 0.13, -0.16),
                            Vec3::new(0.06, 0.06, 0.12),
                        );
                    } else {
                        piece(
                            pivot,
                            visuals.cube_mesh.clone(),
                            visuals.glass_material.clone(),
                            Vec3::new(0.0, 0.0, 0.18),
                            Vec3::new(0.16, 0.16, 0.04),
                        );
                    }
                })
                .id(),
        );

        bras_gauche = Some(
            parent
                .spawn((
                    Transform::from_translation(offset_bras_gauche()),
                    GlobalTransform::default(),
                    Visibility::default(),
                ))
                .with_children(|pivot| {
                    piece(
                        pivot,
                        visuals.sphere_mesh.clone(),
                        visuals.hull_secondary_material.clone(),
                        Vec3::ZERO,
                        Vec3::new(0.14, 0.14, 0.14),
                    );
                    piece(
                        pivot,
                        visuals.cube_mesh.clone(),
                        visuals.suit_fabric_material.clone(),
                        Vec3::new(0.0, -0.22, 0.0),
                        Vec3::new(0.18, 0.36, 0.20),
                    );
                    piece(
                        pivot,
                        visuals.cube_mesh.clone(),
                        materiau_role.clone(),
                        Vec3::new(0.0, -0.08, 0.13),
                        Vec3::new(0.20, 0.04, 0.02),
                    );
                    piece(
                        pivot,
                        visuals.sphere_mesh.clone(),
                        visuals.hull_secondary_material.clone(),
                        Vec3::new(0.0, -0.44, 0.0),
                        Vec3::new(0.11, 0.11, 0.11),
                    );
                    piece(
                        pivot,
                        visuals.cube_mesh.clone(),
                        visuals.suit_fabric_material.clone(),
                        Vec3::new(0.0, -0.66, 0.02),
                        Vec3::new(0.16, 0.32, 0.18),
                    );
                    piece(
                        pivot,
                        visuals.cube_mesh.clone(),
                        visuals.boot_material.clone(),
                        Vec3::new(0.0, -0.90, 0.12),
                        Vec3::new(0.14, 0.10, 0.24),
                    );
                })
                .id(),
        );

        bras_droit = Some(
            parent
                .spawn((
                    Transform::from_translation(offset_bras_droit()),
                    GlobalTransform::default(),
                    Visibility::default(),
                ))
                .with_children(|pivot| {
                    piece(
                        pivot,
                        visuals.sphere_mesh.clone(),
                        visuals.hull_secondary_material.clone(),
                        Vec3::ZERO,
                        Vec3::new(0.14, 0.14, 0.14),
                    );
                    piece(
                        pivot,
                        visuals.cube_mesh.clone(),
                        visuals.suit_fabric_material.clone(),
                        Vec3::new(0.0, -0.22, 0.0),
                        Vec3::new(0.18, 0.36, 0.20),
                    );
                    piece(
                        pivot,
                        visuals.sphere_mesh.clone(),
                        visuals.hull_secondary_material.clone(),
                        Vec3::new(0.0, -0.44, 0.0),
                        Vec3::new(0.11, 0.11, 0.11),
                    );
                    piece(
                        pivot,
                        visuals.cube_mesh.clone(),
                        visuals.suit_fabric_material.clone(),
                        Vec3::new(0.0, -0.66, 0.02),
                        Vec3::new(0.16, 0.32, 0.18),
                    );
                    piece(
                        pivot,
                        visuals.cube_mesh.clone(),
                        visuals.boot_material.clone(),
                        Vec3::new(0.0, -0.90, 0.12),
                        Vec3::new(0.14, 0.10, 0.24),
                    );
                })
                .id(),
        );

        jambe_gauche = Some(
            parent
                .spawn((
                    Transform::from_translation(offset_jambe_gauche()),
                    GlobalTransform::default(),
                    Visibility::default(),
                ))
                .with_children(|pivot| {
                    piece(
                        pivot,
                        visuals.sphere_mesh.clone(),
                        visuals.hull_secondary_material.clone(),
                        Vec3::ZERO,
                        Vec3::new(0.12, 0.12, 0.12),
                    );
                    piece(
                        pivot,
                        visuals.cube_mesh.clone(),
                        visuals.suit_fabric_material.clone(),
                        Vec3::new(0.0, -0.26, 0.0),
                        Vec3::new(0.20, 0.40, 0.24),
                    );
                    piece(
                        pivot,
                        visuals.sphere_mesh.clone(),
                        visuals.hull_secondary_material.clone(),
                        Vec3::new(0.0, -0.52, 0.0),
                        Vec3::new(0.12, 0.12, 0.12),
                    );
                    piece(
                        pivot,
                        visuals.cube_mesh.clone(),
                        visuals.suit_fabric_material.clone(),
                        Vec3::new(0.0, -0.82, 0.02),
                        Vec3::new(0.18, 0.34, 0.22),
                    );
                    piece(
                        pivot,
                        visuals.cube_mesh.clone(),
                        visuals.boot_material.clone(),
                        Vec3::new(0.0, -1.04, 0.10),
                        Vec3::new(0.24, 0.12, 0.38),
                    );
                })
                .id(),
        );

        jambe_droite = Some(
            parent
                .spawn((
                    Transform::from_translation(offset_jambe_droite()),
                    GlobalTransform::default(),
                    Visibility::default(),
                ))
                .with_children(|pivot| {
                    piece(
                        pivot,
                        visuals.sphere_mesh.clone(),
                        visuals.hull_secondary_material.clone(),
                        Vec3::ZERO,
                        Vec3::new(0.12, 0.12, 0.12),
                    );
                    piece(
                        pivot,
                        visuals.cube_mesh.clone(),
                        visuals.suit_fabric_material.clone(),
                        Vec3::new(0.0, -0.26, 0.0),
                        Vec3::new(0.20, 0.40, 0.24),
                    );
                    piece(
                        pivot,
                        visuals.sphere_mesh.clone(),
                        visuals.hull_secondary_material.clone(),
                        Vec3::new(0.0, -0.52, 0.0),
                        Vec3::new(0.12, 0.12, 0.12),
                    );
                    piece(
                        pivot,
                        visuals.cube_mesh.clone(),
                        visuals.suit_fabric_material.clone(),
                        Vec3::new(0.0, -0.82, 0.02),
                        Vec3::new(0.18, 0.34, 0.22),
                    );
                    piece(
                        pivot,
                        visuals.cube_mesh.clone(),
                        visuals.boot_material.clone(),
                        Vec3::new(0.0, -1.04, 0.10),
                        Vec3::new(0.24, 0.12, 0.38),
                    );
                })
                .id(),
        );
    });

    RigAstronaute {
        torse: torse.expect("pivot torse manquant"),
        tete: tete.expect("pivot tete manquant"),
        bras_gauche: bras_gauche.expect("pivot bras gauche manquant"),
        bras_droit: bras_droit.expect("pivot bras droit manquant"),
        jambe_gauche: jambe_gauche.expect("pivot jambe gauche manquant"),
        jambe_droite: jambe_droite.expect("pivot jambe droite manquant"),
    }
}

fn materiau_role(
    visuals: &ColonyVisualAssets,
    role: RoleAstronaute,
) -> Handle<StandardMaterial> {
    match role {
        RoleAstronaute::Commandant => visuals.mission_red_material.clone(),
        RoleAstronaute::Ingenieur => visuals.accent_material.clone(),
        RoleAstronaute::Scientifique => visuals.mission_blue_material.clone(),
        RoleAstronaute::Logisticien => visuals.lit_material.clone(),
        RoleAstronaute::Civil => visuals.storage_material.clone(),
    }
}

#[allow(dead_code)]
fn _silhouette_est_pressurisee(combinaison: TypeCombinaison) -> bool {
    combinaison != TypeCombinaison::Interieure
}
